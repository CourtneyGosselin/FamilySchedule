package com.example.wasi.familyschedualer;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.design.widget.TabLayout;
import android.util.Log;
import java.util.ArrayList;


public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String TAG ="DatabaseHelper";
    private static final String TABLE_NAME ="Wasi";
    private static final String DATE="date";
    private static final String Start="startTime";
    private static final String End="endTime";
    private static final String Location="Location";
    private static final String eventName="EventName";
    private static final String Person="person";
    private static final String Color="color";

    public DatabaseHelper(Context x){
        super(x,TABLE_NAME,null,5);
    }

    @Override
    public void onCreate(SQLiteDatabase sqldb){
        String MakrTable="CREATE TABLE "+ TABLE_NAME+" (\n" +
                "    id integer primary key AUTOINCREMENT, \n" +
                "    date varchar(255),\n" +
                "    startTime varchar(255),\n" +
                "    endTime varchar(255),\n"+
                "    EventName varchar(255),\n"+
                "    Location varchar(255),\n"+
                "    person varchar(255),\n"+
                "    color char(7)" +
                " );";
        sqldb.execSQL(MakrTable);
        // add data to the table
        sqldb.execSQL("INSERT INTO " + TABLE_NAME + " (date, startTime, endTime, EventName, Location, person, color)" +
                "    VALUES ('11/29/18', '18:00', '20:00', 'Dinner with parents', 'at their place', 'Mom', '#59dbe0'), " +
                "    ('11/27/18', '11:00', '12:30', 'Coffee with Sarah', 'Starbucks', 'Mom', '#59dbe0'), " +
                "    ('11/30/18', '13:00', '14:00', 'Dentist''s appointment', 'at dentist''s', 'Mom', '#59dbe0'), " +
                "    ('12/01/18', '15:00', '17:00', 'Helping Luke with his car', 'at Luke''s', 'Dad', '#87d288'), " +
                "    ('12/01/18', '11:00', '12:30', 'Brunch', 'IHOP', 'Mom', '#59dbe0'), " +
                "    ('12/01/18', '20:00', '23:00', 'Movie night', 'at Marvin''s', 'Mark', '#f8b552')," +
                "    ('12/02/18', '13:00', '15:00', 'Swimming class', 'at the pool', 'Lisa', '#f57f68')," +
                "    ('12/01/18', '11:00', '12:30', 'Brunch', 'IHOP', 'Dad', '#87d288')");

        // create request table
        sqldb.execSQL("CREATE TABLE Request (\n" +
                "    id integer primary key AUTOINCREMENT, \n" +
                "    childName varchar(225)," +
                "    date varchar(255),\n" +
                "    startTime varchar(255),\n" +
                "    endTime varchar(255),\n"+
                "    EventName varchar(255),\n"+
                "    Location varchar(255),\n"+
                "    color char(7)" +
                " );");

        sqldb.execSQL("INSERT INTO Request (childName, date, startTime, endTime, EventName, Location, color)" +
                "    VALUES ('Lisa', '11/30/18', '18:00', '21:00', 'Katie''s birthday party', 'Katie''s', '#f57f68'), " +
                "    ('Mark', '11/30/18', '15:00', '16:30', 'Soccer with Lukas', 'at the park', '#f8b552')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqldb, int i, int i1){
        sqldb.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(sqldb);
    }
    public void deleteData() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public ArrayList<Integer> getKeys() {
        ArrayList<Integer> keys = new ArrayList<>();
        SQLiteDatabase db =this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT id FROM Wasi;",null);
        cursor.moveToFirst();
        do  {
            keys.add(cursor.getInt(0));
        } while(cursor.moveToNext());
        db.close();
        return keys;
    }

    public void deleteEvent(int id){
        SQLiteDatabase db =this.getWritableDatabase();
        db.execSQL("DELETE FROM Wasi WHERE  id = "+ id +";");
    }


    public boolean addData(String TableName,String location, String eventname,String date, String start, String end, String person, String color){
        SQLiteDatabase db =this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put(DATE, date);
        contentValues.put(Start, start);
        contentValues.put(End, end);
        contentValues.put(eventName, eventname);
        contentValues.put(Location, location);
        contentValues.put(Person, person);
        contentValues.put(Color, color);

        Log.d(TAG, "addData: Adding "+ date+" "+start+" "+end +" to "+ TABLE_NAME);
        long result =db.insert(TABLE_NAME,null, contentValues);
        if(result==-1)return false;
        else return true;
    }

    public void updateEvent(String TableName, int id, String location, String eventname,String date, String start, String end, String person, String color){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put(DATE, date);
        contentValues.put(Start, start);
        contentValues.put(End, end);
        contentValues.put(eventName, eventname);
        contentValues.put(Location, location);
        contentValues.put(Person, person);
        contentValues.put(Color, color);
        db.execSQL("UPDATE " + TableName + " SET " +
                "date = \'" + date +
                "\', startTime = \'" + start +
                "\', endTime = \'" + end +
                "\', EventName = \'" + eventname +
                "\', Location = \'" + location +
                "\', person = \'" + person +
                "\', color = \'" + color +
                "\' WHERE id = " + id);
    }

    public  String getData(String column, int id){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select *  from " + TABLE_NAME + " WHERE id = " +  id + ";",null);
        String data = "";
        if(cursor.moveToFirst()) {
             data = cursor.getString(cursor.getColumnIndex(column));
        }
        db.close();
        return data;
    }

    public  ArrayList<String> getEventRequest(int id){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select *  from Request WHERE id = " +  id + ";",null);
        ArrayList<String> request = new ArrayList<String>();
        if(cursor.moveToFirst()) {
            for (int i = 0; i < 8; i++) {
                request.add(cursor.getString(i));
            }
        }
        db.close();
        return request;
    }

    public void acceptRequest(int id) {
        // add to event table and remove from request table
        SQLiteDatabase db =this.getWritableDatabase();
        db.execSQL("INSERT INTO " + TABLE_NAME + " (date, startTime, endTime, EventName, Location, person, color) " +
                "    SELECT date, startTime, endTime, EventName, Location, childName, color FROM Request WHERE id = " + id);
        removeRequest(id);
    }

    public void removeRequest(int id) {
        SQLiteDatabase db =this.getWritableDatabase();
        db.execSQL("DELETE FROM REQUEST WHERE id = " + id);
    }
}
