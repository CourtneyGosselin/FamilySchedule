package com.example.wasi.familyschedualer;

import android.graphics.Color;
import com.alamkanak.weekview.WeekViewEvent;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * A basic example of how to use week view library.
 * Created by Raquib-ul-Alam Kanak on 1/3/2014.
 * Website: http://alamkanak.github.io
 */
public class MainActivity extends Main2Activity {

    @Override
    public List<? extends WeekViewEvent> onMonthChange(int newYear, int newMonth) {
        // Populate the week view with some events.
        List<WeekViewEvent> events = new ArrayList<WeekViewEvent>();

        DatabaseHelper db = new DatabaseHelper(this);
        for(Integer i : db.getKeys()) {
                String[] SplitDate=db.getData("date", i).split("/") ;
                if(Integer.toString(newMonth).equals(SplitDate[0]) && Integer.toString(newYear).endsWith(SplitDate[2])) {
                    String[] STime=db.getData("startTime", i).split(":") ;
                    String[] ETime=db.getData("endTime", i).split(":") ;
                    Calendar startTime = Calendar.getInstance();
                    startTime.set(Calendar.DAY_OF_MONTH, Integer.parseInt(SplitDate[1]));
                    startTime.set(Calendar.MONTH, Integer.parseInt(SplitDate[0])-1);
                    startTime.set(Calendar.YEAR, 2000+Integer.parseInt(SplitDate[2]) );
                    startTime.set(Calendar.SECOND, 0);

                    startTime.set(Calendar.HOUR_OF_DAY,Integer.parseInt(STime[0]) );
                    startTime.set(Calendar.MINUTE, Integer.parseInt(STime[1]));

                    Calendar endTime = (Calendar) startTime.clone();
                    endTime.set(Calendar.HOUR_OF_DAY, Integer.parseInt(ETime[0]));
                    endTime.set(Calendar.MINUTE,Integer.parseInt(ETime[1]));

                    WeekViewEvent event = new WeekViewEvent(i, db.getData("EventName", i), startTime, endTime);
                    event.setColor(Color.parseColor(db.getData("color", i)));
                    events.add(event);
            }
        }
        return events;
    }
}
