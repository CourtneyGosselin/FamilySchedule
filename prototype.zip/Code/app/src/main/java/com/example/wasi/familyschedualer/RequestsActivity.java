package com.example.wasi.familyschedualer;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class RequestsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_requests);

        DatabaseHelper db = new DatabaseHelper(this);
        ArrayList<String> requestInformation = db.getEventRequest(1);
        String request = "";
        TextView textViewRequest1 = (TextView) findViewById(R.id.textViewRequest1);
        if(!requestInformation.isEmpty()) {
            request = "Request by: " + requestInformation.get(1);
            request += "\nName: " + requestInformation.get(5);
            request += "\nDate: " + requestInformation.get(2);
            request += "\nStart Time: " + requestInformation.get(3);
            request += "\nEnd Time: " + requestInformation.get(4);
            request += "\nLocation: " + requestInformation.get(6);
            textViewRequest1.setText(request);
            textViewRequest1.setBackgroundColor(Color.parseColor(requestInformation.get(7)));
        } else {
            textViewRequest1.setVisibility(View.GONE);
            findViewById(R.id.layout1).setVisibility(View.GONE);
        }

        TextView textViewRequest2 = (TextView) findViewById(R.id.textViewRequest2);
        requestInformation = db.getEventRequest(2);
        if(!requestInformation.isEmpty()) {
            request = "Request by: " + requestInformation.get(1);
            request += "\nName: " + requestInformation.get(5);
            request += "\nDate: " + requestInformation.get(2);
            request += "\nStart Time: " + requestInformation.get(3);
            request += "\nEnd Time: " + requestInformation.get(4);
            request += "\nLocation: " + requestInformation.get(6);
            textViewRequest2.setText(request);
            textViewRequest2.setBackgroundColor(Color.parseColor(requestInformation.get(7)));
        } else {
            textViewRequest2.setVisibility(View.GONE);
            findViewById(R.id.layout2).setVisibility(View.GONE);         }
    }

    public void accept1(View view) {
        DatabaseHelper db = new DatabaseHelper(this);
        db.acceptRequest(1);
        Intent intent = new Intent(this, MainActivity.class);
        finish();
        startActivity(intent);
    }

    public void accept2(View view) {
        DatabaseHelper db = new DatabaseHelper(this);
        db.acceptRequest(2);
        Intent intent = new Intent(this, MainActivity.class);
        finish();
        startActivity(intent);
    }

    public void decline1(View view) {
        DatabaseHelper db = new DatabaseHelper(this);
        db.removeRequest(1);
        LinearLayout layout = findViewById(R.id.layout1);
        findViewById(R.id.textViewRequest1).setVisibility(View.GONE);
        findViewById(R.id.layout1).setVisibility(View.GONE);
    }

    public void decline2(View view) {
        DatabaseHelper db = new DatabaseHelper(this);
        db.removeRequest(2);
        findViewById(R.id.textViewRequest2).setVisibility(View.GONE);
        findViewById(R.id.layout2).setVisibility(View.GONE);
    }
}
