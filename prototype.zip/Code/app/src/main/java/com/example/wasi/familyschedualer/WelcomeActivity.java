package com.example.wasi.familyschedualer;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class WelcomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
    }

    public void showSchedule(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void addEvent(View view) {
        Intent intent = new Intent(this, addevent.class);
        startActivity(intent);
    }

    public void showEventRequests(View view) {
        Intent intent = new Intent(this, RequestsActivity.class);
        startActivity(intent);
    }

}
