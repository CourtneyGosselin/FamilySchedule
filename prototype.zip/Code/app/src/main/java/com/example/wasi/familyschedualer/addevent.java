package com.example.wasi.familyschedualer;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class addevent extends AppCompatActivity {

    int id = 0;
    Calendar myCalendar;
    EditText starttime;
    EditText eventName;
    EditText Location;
    EditText endTime;
    EditText date;
    Switch allDaySwitch;
    Spinner personSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addevent);

        eventName= findViewById(R.id.eventname);
        Location=findViewById(R.id.location);
        date=findViewById(R.id.date);
        starttime=findViewById(R.id.timestart);
        endTime= findViewById(R.id.timeend);
        allDaySwitch= findViewById(R.id.alldayswitch);
        personSpinner=findViewById(R.id.spinnerPerson);

        personSpinner.setOnItemSelectedListener(new  AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                // change color
                ((TextView) findViewById(R.id.textViewColor)).setBackgroundColor(Color.parseColor(getColorForPerson(personSpinner.getSelectedItem().toString())));
            }
            // If no option selected
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });

        personSpinner.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    // change color
                     ((TextView) findViewById(R.id.textViewColor)).setBackgroundColor(Color.parseColor(getColorForPerson(personSpinner.getSelectedItem().toString())));
                }
                return false;
            }
        });
        String person = "Mom"; // default for the spinner

        // get extras if any are set
        Intent intent = getIntent();

        // Get the extras (if there are any)
        Bundle extras = intent.getExtras();
        if (extras != null) {
            id = intent.getIntExtra("id", 0);
            eventName.setText(intent.getStringExtra("eventName"));
            date.setText(intent.getStringExtra("date"));
            starttime.setText(intent.getStringExtra("startTime"));
            endTime.setText(intent.getStringExtra("endTime"));
            Location.setText(intent.getStringExtra("location"));
            person = intent.getStringExtra("person");
            if(person.equals("Mom"))
                personSpinner.setSelection(0);
            else if(person.equals("Dad"))
                personSpinner.setSelection(1);
            else if(person.equals("Lisa"))
                personSpinner.setSelection(2);
            else if(person.equals("Mark"))
                personSpinner.setSelection(3);
            ((Button) findViewById(R.id.button5)).setText("SAVE CHANGES");
        }
        ((TextView) findViewById(R.id.textViewColor)).setBackgroundColor(Color.parseColor(getColorForPerson(person)));
    }

    /////////////////////////////////////time handling //////////////////////////////////////////////////////////////////////
    DatePickerDialog.OnDateSetListener Todaydate = new DatePickerDialog.OnDateSetListener() {

        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {
            myCalendar.set(Calendar.YEAR, year);
            myCalendar.set(Calendar.MONTH, monthOfYear);
            myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            updateLabel();
        }

    };

    public void AllDaySwitch(View v){
        if(allDaySwitch.isChecked()){// disable editing password
                starttime.setFocusable(false);
                starttime.setEnabled(false);
                starttime.setFocusableInTouchMode(false); // user touches widget on phone with touch screen
                starttime.setClickable(false); // user navigates with wheel and selects widget
                starttime.setBackgroundColor(0xBFBFBFBF);
                endTime.setFocusable(false);
                endTime.setEnabled(false);
                endTime.setFocusableInTouchMode(false); // user touches widget on phone with touch screen
                endTime.setClickable(false); // user navigates with wheel and selects widget
                endTime.setBackgroundColor(0xBFBFBFBF);
                starttime.setText("00:00");
                endTime.setText("12:00");
            }else { // enable editing of password
                starttime.setFocusable(true);
                starttime.setFocusableInTouchMode(true);
                starttime.setClickable(true);
                starttime.setEnabled(true);
                starttime.setBackgroundColor(0xF2F2F2F2);
                endTime.setFocusable(true);
                endTime.setFocusable(true);
                endTime.setFocusableInTouchMode(true);
                endTime.setClickable(true);
                endTime.setEnabled(true);
                endTime.setBackgroundColor(0xF2F2F2F2);
        }
    }

    private void updateLabel() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.CANADA);

        date.setText(sdf.format(myCalendar.getTime()));
    }

    public void dateGetter(View v){
        myCalendar = Calendar.getInstance();
        new DatePickerDialog(this, Todaydate, myCalendar
                .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH)).show();
    }

    public void timeStartGetter(View v){
        myCalendar = Calendar.getInstance();
        int hour = myCalendar.get(Calendar.HOUR_OF_DAY);
        int minute = myCalendar.get(Calendar.MINUTE);
        TimePickerDialog mTimePicker;
        mTimePicker = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                if(selectedMinute < 10) {
                    starttime.setText( selectedHour + ":0" + selectedMinute);
                } else {
                    starttime.setText( selectedHour + ":" + selectedMinute);
                }
            }
        }, hour, minute, true);//Yes 24 hour time
        mTimePicker.setTitle("Select Time");
        mTimePicker.show();
    }

    public void timeEndGetter(View v){
        myCalendar = Calendar.getInstance();
        int hour = myCalendar.get(Calendar.HOUR_OF_DAY);
        int minute = myCalendar.get(Calendar.MINUTE);
        TimePickerDialog mTimePicker;
        mTimePicker = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                if(selectedMinute < 10) {
                    endTime.setText( selectedHour + ":0" + selectedMinute);
                } else {
                    endTime.setText( selectedHour + ":" + selectedMinute);
                }
            }
        }, hour, minute, true);//Yes 24 hour time
        mTimePicker.setTitle("Select Time");
        mTimePicker.show();
    }
////////////////////////////////////////////////////////////Adding data in db/////////////////////////////////////////////////////////////////////////////////////////

    public void AddData(View v){
        boolean insertData=false;

        DatabaseHelper db = new DatabaseHelper(this);
        if(eventName.getText().toString().equals(""))
            Toast.makeText(this, "Please enter an event name", Toast.LENGTH_LONG).show();
        else if(date.equals(""))
            Toast.makeText(this, "Please enter an event date", Toast.LENGTH_LONG).show();
        else if(starttime.equals(""))
            Toast.makeText(this, "Please enter a start time", Toast.LENGTH_LONG).show();
        else if(endTime.getText().toString().equals(""))
            Toast.makeText(this, "Please enter an end time", Toast.LENGTH_LONG).show();
        else {
            // check if the end time is after the start time
            String[] startParts = starttime.getText().toString().split(":");
            String[] endParts = endTime.getText().toString().split(":");
            if(startParts[0].startsWith("0")) startParts[0] = startParts[0].substring(1);
            if(startParts[1].startsWith("0")) startParts[1] = startParts[1].substring(1);
            if(endParts[0].startsWith("0")) endParts[0] = endParts[0].substring(1);
            if(endParts[1].startsWith("0")) endParts[1] = endParts[1].substring(1);

            if(Integer.parseInt(endParts[0]) <= Integer.parseInt(startParts[0]) && Integer.parseInt(endParts[1]) <= Integer.parseInt(startParts[1]))
                Toast.makeText(this, "The start time needs to be before the end time", Toast.LENGTH_LONG).show();
            else if(Location.getText().toString().equals(""))
                Toast.makeText(this, "Please enter a location", Toast.LENGTH_LONG).show();
            else {
                if(id != 0) { // edit event
                    db.updateEvent("Wasi", id, Location.getText().toString(), eventName.getText().toString(), date.getText().toString(), starttime.getText().toString(), endTime.getText().toString(), personSpinner.getSelectedItem().toString(), getColorForPerson(personSpinner.getSelectedItem().toString()));
                    Intent intent = new Intent(this, eventDetail.class);
                    Toast.makeText(this, "Event successfully updated", Toast.LENGTH_LONG).show();
                    intent.putExtra("id", id);
                    intent.putExtra("eventName", eventName.getText().toString());
                    SimpleDateFormat dateFormat = new SimpleDateFormat("mm/dd/yy   hh:mm");
                    intent.putExtra("startTime",  date.getText().toString() + "   " + starttime.getText().toString());
                    intent.putExtra("endTime", date.getText().toString() + "   " + endTime.getText().toString());
                    finish();
                    startActivity(intent);
                } else {
                    insertData = db.addData("Wasi", Location.getText().toString(), eventName.getText().toString(), date.getText().toString(), starttime.getText().toString(), endTime.getText().toString(), personSpinner.getSelectedItem().toString(), getColorForPerson(personSpinner.getSelectedItem().toString()));
                    if (insertData) {
                        Toast.makeText(this, "Event successfully added", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(this, MainActivity.class);
                        finish();
                        startActivity(intent);
                    }
                    else Toast.makeText(this, "Event not added", Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void InvitingPpl(View v){
        Intent intent = new Intent(this, invitingPpl.class);
        intent.putExtra("eventName",eventName.getText().toString() );
        intent.putExtra("Location",Location.getText().toString() );
        intent.putExtra("startTime",starttime.getText().toString() );
        intent.putExtra("endTime",endTime.getText().toString() );
        intent.putExtra("date",date.getText().toString() );

        startActivity(intent);
    }

    public void DropData( View v){
        DatabaseHelper db = new DatabaseHelper(this);
        db.deleteData();
    }
    /////////////////////////////////////////////////////////////////////////////////File add//////////////////////////////////////////////////////////////////////////////////////

    public void getFile(View v){
        Intent intent = new Intent()
                .setType("*/*")
                .setAction(Intent.ACTION_GET_CONTENT);

        startActivityForResult(Intent.createChooser(intent, "Select a .sch file"), 123);
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==123 && resultCode==RESULT_OK) {
            Uri selectedfile = data.getData(); //The uri with the location of the file
            StringBuilder text = new StringBuilder();
            try {
                String file = selectedfile.toString();
                FileInputStream fis = openFileInput(file);
                InputStreamReader isr = new InputStreamReader(fis);
                BufferedReader br = new BufferedReader(isr);
                String line;
                while ((line = br.readLine()) != null) {
                    text.append(line+"\n");

                }
                String[] Lines=text.toString().split(",");
                br.close() ;

                boolean insertData=false;
                DatabaseHelper db = new DatabaseHelper(this);
                if(Lines[1].equals("")|Lines[4].equals("")||Lines[0].equals("")||Lines[2].equals("")||Lines[3].equals(""))
                    Toast.makeText(this,"Field Empty ", Toast.LENGTH_LONG).show();
                else {
                    insertData = db.addData("Wasi", Lines[1], Lines[0], Lines[2], Lines[3], Lines[4], personSpinner.getSelectedItem().toString(), getColorForPerson(personSpinner.getSelectedItem().toString()));
                    if (insertData) {
                        Toast.makeText(this, "Event successfully added", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(this, MainActivity.class);
                        finish();
                        startActivity(intent);
                    } else Toast.makeText(this, "Event not added", Toast.LENGTH_LONG).show();
                }
            }catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public String getColorForPerson(String person) {
        String color = "";
        if(person.equals("Mom")) {
            color = "#59dbe0";
        } else if(person.equals("Dad")) {
            color = "#87d288";
        } else if(person.equals("Lisa")) {
            color = "#f57f68";
        } else if(person.equals("Mark")) {
            color = "#f8b552";
        }
        return color;
    }

}
