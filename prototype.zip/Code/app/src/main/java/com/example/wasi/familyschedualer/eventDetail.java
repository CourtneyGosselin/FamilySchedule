package com.example.wasi.familyschedualer;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class eventDetail extends AppCompatActivity {

    int id;
    String eventName;
    String starTime;
    String endTime;
    String location;
    String person;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_detail);
        id = getIntent().getIntExtra("id", 0);
        eventName= getIntent().getStringExtra("eventName");
        starTime= getIntent().getStringExtra("startTime");
        endTime= getIntent().getStringExtra("endTime");

        ((TextView) findViewById(R.id.textViewName)).setText(eventName);
        ((TextView) findViewById(R.id.textViewStart)).setText(starTime);
        ((TextView) findViewById(R.id.textViewEnd)).setText(endTime);

        DatabaseHelper db = new DatabaseHelper(this);
        location = db.getData("Location", id);
        ((TextView) findViewById(R.id.textViewLocation)).setText(location);
        person = db.getData("person", id);
        TextView textViewPerson = (TextView) findViewById(R.id.textViewPerson);
        textViewPerson.setText(person);
        textViewPerson.setBackgroundColor(Color.parseColor(db.getData("color", id)));
    }

    public void deleteEvent(View v) {
        DatabaseHelper db =new DatabaseHelper(this);
        db.deleteEvent(id);
        Intent intent = new Intent(this, MainActivity.class);
        finish();
        startActivity(intent);
    }

    public void editEvent(View v) {
        Intent intent = new Intent(this, addevent.class);
        intent.putExtra("id", id);
        intent.putExtra("eventName", eventName);
        intent.putExtra("date", starTime.substring(0, 8));
        intent.putExtra("startTime", starTime.substring(11));
        intent.putExtra("endTime", endTime.substring(11));
        intent.putExtra("location", location);
        intent.putExtra("person", person);
        finish();
        startActivity(intent);
    }
}
