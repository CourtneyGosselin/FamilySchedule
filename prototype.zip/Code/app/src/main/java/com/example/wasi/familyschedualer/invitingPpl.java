package com.example.wasi.familyschedualer;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.BitmapDrawable;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Environment;
import android.os.SystemClock;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;

public class invitingPpl extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inviting_ppl);
    }

    public void emailPpl(View v){
        String filename = "data.sch";
        String eventName= getIntent().getStringExtra("eventName");
        String Location= getIntent().getStringExtra("Location");
        String starTime= getIntent().getStringExtra("startTime");
        String endTime= getIntent().getStringExtra("endTime");
        String date= getIntent().getStringExtra("date");

        String fileContents = eventName + "," + Location + "," + date + "," + starTime + "," + endTime + "\n";
        FileOutputStream outputStream;
        try {

            File file = new File(getBaseContext().getFilesDir(), filename);
            outputStream = openFileOutput(filename, Context.MODE_APPEND);
            outputStream.write(fileContents.getBytes());
            outputStream.close();
            Toast.makeText(this, "write complete",
                    Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            e.printStackTrace();
        }

        EditText emails= findViewById(R.id.editText2);
        EditText Message= findViewById(R.id.editText4);
        String[] to = emails.getText().toString().split(",");



        File filelocation = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), filename);
        Uri path = FileProvider.getUriForFile(this, this.getApplicationContext().getPackageName() + ".provider", filelocation);
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
// set the type to 'email'
        emailIntent .setType("*/*");
        emailIntent .putExtra(Intent.EXTRA_EMAIL, to);
        emailIntent.putExtra(Intent.EXTRA_TEXT, Message.getText().toString()+"\n Thank you for using Family Scheduler");
// the attachment
        emailIntent .putExtra(Intent.EXTRA_STREAM, path);
// the mail subject
        emailIntent .putExtra(Intent.EXTRA_SUBJECT, "You are Invited to "+ eventName);
        startActivity(Intent.createChooser(emailIntent , "Send email..."));
    }
    public void scheduleNotification(Context context, long delay, int notificationId,String eventName) {//delay is after how much time(in millis) from current time you want to schedule the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context)
                .setContentTitle("Family Schedual")
                .setContentText("You have "+ eventName+ "  coming up")
                .setAutoCancel(true)
                .setSmallIcon(R.drawable.logo)
                .setLargeIcon(((BitmapDrawable) context.getResources().getDrawable(R.drawable.logo)).getBitmap())
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));

        Intent intent = new Intent(context, MainActivity.class);
        PendingIntent activity = PendingIntent.getActivity(context, notificationId, intent, PendingIntent.FLAG_CANCEL_CURRENT);
        builder.setContentIntent(activity);

        Notification notification = builder.build();

        Intent notificationIntent = new Intent(context, MainActivity.class);
        notificationIntent.putExtra(MyNotificationPublisher.NOTIFICATION_ID,notification);
        notificationIntent.putExtra(MyNotificationPublisher.NOTIFICATION, notification);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, notificationId, notificationIntent, PendingIntent.FLAG_CANCEL_CURRENT);

        long futureInMillis = SystemClock.elapsedRealtime() + delay;
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, futureInMillis, pendingIntent);
    }

}
